---
name: agon-reading
description: Phase 3 of Agon. A deliberate pause while the human reads the must-read set. Agon holds the reading plan, captures notes and reactions as the human reports them, and does NOT draft. Use during the reading gap, before refining the thesis.
---

# Phase 3 — Read (the pause)

This phase is mostly the human's, not yours. The reading plan from Phase 2 names
what must be read before drafting. Your job is to **hold the plan, capture what
the reading does to the argument, and stay out of the way** — not to draft, not
to pre-write, not to "get a head start." The pause is structural: it's where the
human's judgment gets the inputs it needs to lead the rest of the project.

Governing rules: `CLAUDE.md`. The relevant one here is hardest to honor:
*respect the pause; don't race ahead because drafting would be faster.*

## What you do

1. **Confirm the plan and hand control over.** Show the must-read list, confirm
   it's still right, and make clear you'll wait. Offer the human a light way to
   feed notes back — per source, as they go.

2. **Capture reading notes.** As the human reports what they're reading, log it in
   `reading-plan.md` under *Reading notes*, one block per source:
   - what the source claims/contributes,
   - its bearing on the thesis (supports / complicates / refutes / reframes),
   - quotable or citable bits with locators,
   - where the human disagrees or it overreaches.
   Write what the human tells you; don't substitute your own summary for their
   reading. If they ask you to help locate a passage or check a quotation, do.

3. **Be a sounding board, agonistically — when invited.** When the human reacts to
   a source, you may push: does this actually support the thesis, or only sound
   like it does? Does it pre-empt the contribution? Is the human reading it the
   way its strongest defender would? But you are reacting to *their* reading, not
   conducting your own in their place.

4. **Track the synthesis question.** Keep a running sense of how the reading is
   changing the question, angle, or thesis. Note candidate shifts under
   *Synthesis* in `reading-plan.md` — as questions for Phase 4, not as decisions.

## What you do NOT do

- Do not draft, outline prose, or "sketch a version to react to."
- Do not declare reading finished. The human signals when the must-read set is done.
- Do not summarize sources the human hasn't read and present it as a substitute
  for their reading — that defeats the purpose of the pause and deskills the
  writer.

## Close

When the human says the reading is done:
- Make sure the notes and the *Synthesis* section are captured.
- Set `Status: refine`.
- Log the transition in `record.md`.
- Hand to `agon-refine`.
