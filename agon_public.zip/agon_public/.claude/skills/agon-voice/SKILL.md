---
name: agon-voice
description: Build or update the voice profile from the corpus of past publications in voice/. Dispatches the voice-analyst subagent, reviews the profile with the human, and saves voice/voice-profile.md. Use when the corpus is first populated or when new writing should update the profile.
---

# Voice profiling

Goal: a `voice/voice-profile.md` that keeps new writing recognizably the human's
*while improving on it*. The profile captures characteristic moves to amplify and
recurring infelicities to leave behind. It is reference for Layer 4 of drafting
(word choice and voice) — and a check against flattening the voice into generic
competence.

Governing rules: `CLAUDE.md`, especially rule 10: ground in the corpus, surpass
its infelicities. The corpus is never a cage; documented tics exist to be left
behind.

## Procedure

1. **Check the corpus.** Look in `voice/` (and any subfolders). If it's empty,
   tell the human how to populate it (copy files in, paste text, or ask for help
   pulling from Google Drive) and stop — there's nothing to analyze yet.

2. **Dispatch the analyst.** Launch the `voice-analyst` subagent over the corpus.
   It returns a structured profile: registers, characteristic moves, sentence
   signature, lexical fingerprint, infelicities, and notes for the editor —
   grounded in quoted examples. It analyzes only; it does not write to disk.

3. **Review with the human — they have veto.** Voice is personal and the human
   knows themselves better than any analysis. Walk through the profile:
   - Do the "characteristic moves" feel like them, or like generic praise?
   - Do the flagged infelicities ring true, or is the analyst mistaking a
     deliberate choice for a tic? (Push gently if you think a "choice" is actually
     a crutch — with the example — but defer; this is their voice.)
   - Are the registers right for the genres they write?

4. **Save.** Write the agreed profile to `voice/voice-profile.md`, replacing the
   placeholder. Note the date and which corpus files informed it.

## Updating

When the human publishes something new or wants the profile refreshed, re-run.
Note what changed — a voice evolves, and the profile should track growth, not
freeze the writer at an earlier stage.

## Use downstream

The profile is loaded by `agon-draft` at Layer 4 and by the `agonistic-editor`
when working the word layer. Its job there is to help the human write the *best*
version of their voice — amplifying what works, retiring what doesn't.
