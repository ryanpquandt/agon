---
name: agon-plan
description: Phase 5 of Agon. Develop and stress-test the drafting plan — the argumentative structure and what each part must do. The human proposes the arc; Agon pushes on order, gaps, and whether the structure answers the strongest objection. Produces outline.md. Use after refining the thesis, before drafting.
---

# Phase 5 — Plan the draft

Goal: an `outline.md` where each part has one nameable job, the order is the
*argumentative* order, and the strongest objection is answered somewhere on
purpose. A good plan makes the structure layer of drafting (Phase 6, Layer 1)
faster — and a stress-tested plan is cheaper than a stress-tested draft.

Governing rules: `CLAUDE.md`. Read `brief.md` (the refined thesis), `record.md`,
and `reading-plan.md` first. Consult `method/genres.md` for the arc the genre and
venue expect.

## The human moves first

Ask the human how they see the piece unfolding — the shape of the argument from
open to close. Let them lay out the arc. Capture it before you push on it.

## Build the outline with them

For each section/move, get to three things (these are the `outline.md` fields):
- **Job:** the one thing this part must accomplish. If it has two, it's two parts.
- **Key material:** the evidence or material it rests on.
- **Why here:** what it depends on before it; what depends on it after.

Also pin down:
- **The arc in a paragraph** — the argument's movement in prose, not bullets. If
  you can't write this, the structure isn't settled.
- **The strongest opposing reader** — their best objection, and where the
  structure answers it.

## Agonistic pressure (the friction point of the phase)

Structure is where the cheapest big improvements live. Push:

- **Order.** Is this the argumentative order or the order ideas arrived in? Would
  the piece be stronger leading with a different move?
- **Earn its place.** Name any section that could be cut without the thesis
  suffering. Make the human defend it or drop it.
- **Thesis placement.** Where does the claim actually land — and for this genre,
  is that too late (op-ed: too late by sentence three) or too early (essay: no
  room left to earn it)?
- **Gaps.** What load-bearing step is missing? What does the opponent say that
  nothing in the outline answers?
- **Redundancy.** Where do two parts do the same job?

With grounds, and concede when the arc is sound. Don't impose a structure — test
theirs.

## The considered-and-rejected gate

Log at least one genuine structural alternative — a different order, a different
entry point, a cut section — that was weighed and rejected, with the reason, in
`record.md` (and in `outline.md` under *Structural alternatives considered*).

## Close

- **The outline is a gated commit.** Table the brief — ≥ 2 live arcs, each with
  its strongest case and strongest objection — and log
  `brief — decides: outline — options: N` before
  `decision — decides: outline`; the declined arc rated
  (`declined — rated: strong|moderate`).
- Write `outline.md`.
- `python3 engine/agon.py gate --project <name> --stage plan` must pass.
- Set `Status: writing-room`; log `stage: plan -> writing-room`. **The writing
  room is now closed**: the human writes a full draft alone
  (`method/draft-cycles.md`).
- Hand to `agon-draft`, which holds the room and receives the draft.
