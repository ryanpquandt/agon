---
name: agon-refine
description: Phase 4 of Agon. After the reading, revise the question, angle, and thesis in light of what was learned. The human proposes the revision; Agon pressure-tests it against the reading notes and the strongest opposing view. Use after the reading gap, before planning the draft.
---

# Phase 4 — Refine

Goal: a revised question, angle, and thesis that reflect the reading — written
back into `brief.md`, with the change reasoned out in `record.md`. The provisional
claims from Phase 1 were a starting bet; the reading is the evidence. Now the team
decides what to actually argue.

Governing rules: `CLAUDE.md`. Read `brief.md`, `reading-plan.md` (especially
*Synthesis*), and `record.md` first.

## The human moves first

Ask the human how the reading changed their thinking. What survived? What broke?
Where does the thesis need to narrow, sharpen, or shift? Let them propose the
revision. Don't hand them a new thesis — draw out theirs.

## Pressure-test the revision (this is the friction point)

This is where the reading earns its keep. Test the proposed thesis against what
was actually read:

- **Is it still arguable, and now defensible?** The reading should have made the
  claim sharper *and* better defended, not just safer.
- **Does any must-read source already make or refute it?** If someone got there
  first, the contribution has to move. Name it.
- **Does it answer the strongest opposing view** surfaced in the reading? Put that
  view at its strongest and see if the thesis survives.
- **Did the reading reveal a better question?** Sometimes the real find is that
  the original question was the wrong one. If so, say it — even though it's costly.
- **Does the angle fit the venue and genre** still? Refinement can drift a piece
  out of its target; check.

Push with grounds, citing the reading notes. Concede when the human's revision is
well-supported. If the revision is frictionless, suspect under-reading or
anchoring on the Phase 1 frame — probe before accepting.

## The considered-and-rejected gate

Log at least one genuine alternative thesis/angle that was weighed and rejected
here, with the reason, in `record.md`. The point is to show the chosen claim beat
a real competitor on the merits.

## Close

- Update `brief.md`: revised question, angle, thesis. Note in the brief that these
  are now post-reading (no longer provisional), and keep a one-line trace of what
  changed.
- Record the thesis evolution in the Ledger: the re-commit is gated like the
  original — `brief — decides: thesis — options: N` (the pre-reading thesis and
  its post-reading revision are two live options at minimum) before
  `decision — decides: thesis`; the declined path rated
  (`declined — rated: strong|moderate`).
- `python3 engine/agon.py gate --project <name> --stage refine` must pass.
- Set `Status: plan`; log `stage: refine -> plan`.
- Hand to `agon-plan`.
