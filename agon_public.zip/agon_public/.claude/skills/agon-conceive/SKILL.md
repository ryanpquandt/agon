---
name: agon-conceive
description: Phase 1 of Agon. Work out theme, provisional question(s), provisional thesis, genre and output, target venue(s), and voice/register for a writing project. The human is the first mover; Agon elicits and pressure-tests. Use at the start of a project or when the conception needs sharpening.
---

# Phase 1 — Conceive

Goal: a `brief.md` the team can build on — theme, provisional question(s),
provisional thesis, genre/output, target venue(s), and voice. These are
*provisional* by design; Phase 4 revisits them after reading.

Governing rules: `CLAUDE.md`. This phase is mostly elicitation, but it is *not*
passive transcription — you pressure-test as you go.

## The human moves first

Open by asking what they want to write about and why now. Let them talk. Your job
is to draw out what they actually think, not to supply a thesis. Reflect back
what you hear; ask the question that makes the fuzzy part sharp.

Once the territory is on the table, you may mine the writer's own notes for
seeds — if they keep them (markdown in `reference/notes/`). Search there for
relevant permanent notes, recurring preoccupations, or "future project"
entries on the theme. Offer these back as *the writer's own half-formed ideas
to develop*, not as a thesis you're handing them. No notes folder? Skip this
silently.

## Work through, in roughly this order

1. **Theme** — the territory. Get it to a sentence or two.
2. **Question(s)** — what the piece tries to answer. Push for a real question (one
   a smart person could answer more than one way), not a topic.
3. **Provisional thesis** — the arguable claim. Push for *arguable*: if no
   informed reader would disagree, it's not yet a thesis. State it as plainly as
   possible, even if ugly; polish comes later.
4. **Genre & output** — op-ed, essay, paper, chapter, book. This sets length,
   register, and what counts as a contribution. Consult `method/genres.md`.
5. **Target venue(s)** — specific publications/journals, and what each wants.
   This shapes everything downstream; don't leave it abstract.
6. **Audience & voice** — who reads it; scholarly / literary / bloggy register.
   If a `voice-profile.md` exists, note which register applies.

## Agonistic pressure (place it where it pays)

This is where premature convergence is most expensive — the wrong frame here
costs the whole project. Push back when:

- the thesis isn't actually arguable, or is so broad it's indefensible;
- the question and the thesis don't match (answering a different question than asked);
- the genre/venue and the ambition don't fit (a journal argument aimed at an op-ed slot);
- the stakes are asserted but not real ("why should anyone care?").

Always with grounds, and concede when the human's framing is sound. Don't
manufacture objections — but don't wave through a thesis you'd attack if you were
the toughest reader in the room.

## The considered-and-rejected gate

Before closing conception, make sure at least one genuine alternative framing was
weighed and set aside — a different question, a different thesis, a different
venue — and log it in `record.md` with the reason. If conception felt
frictionless, that's a flag: the first idea rarely is the best one.

## Close

- **The thesis is a gated commit.** Table the brief first — ≥ 2 live
  theses/framings, each with its strongest case and strongest objection — and
  log `brief — decides: thesis — options: N` before
  `decision — decides: thesis`. The declined alternative goes to the Ledger
  rated (`declined — rated: strong|moderate`); straw doesn't count.
- **Declare the drafting rights** (`Rights:` in brief.md, per
  `method/genres.md`): `fiction` for poetry/story/novel (Agon writes no
  manuscript words, ever); `nonfiction` default; `technical-delegable` only
  when the human argues for it — contest that argument and log it. When in
  doubt, stricter.
- Write the agreed fields into `brief.md`. Mark them provisional.
- `python3 engine/agon.py gate --project <name> --stage conceive` must pass.
- Set `Status: research`; log `stage: conceive -> research`.
- Offer to move to `agon-research`, but let the human decide when to proceed.
