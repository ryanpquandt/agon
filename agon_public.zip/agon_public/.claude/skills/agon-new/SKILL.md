---
name: agon-new
description: Scaffold a new Agon writing project. Creates projects/<name>/ from the template (brief, reading-plan, record, outline, drafts/) and starts the conception conversation. Use when the user wants to start a new piece of writing.
---

# Agon — new project

Create a new project folder and begin. Keep the human as first mover: you set up
the scaffold, but the conception is theirs to drive.

## Procedure

1. **Get a working title / slug.** Ask the human for a short name (or propose one
   from what they've said and confirm it). Derive a filesystem-safe slug
   (kebab-case).

2. **Create the folder** by copying the template:
   - Copy `projects/_TEMPLATE/` to `projects/<slug>/` (preserve the structure:
     `brief.md`, `reading-plan.md`, `record.md`, `outline.md`, `drafts/`).
   - Use a shell copy (e.g. `cp -R`) so the template stays intact.

3. **Stamp the brief.** Fill the title and the `Started` / `Last touched` dates
   in `brief.md`. Set `Status: conceive`. Leave the substantive fields for the
   human to fill in conception.

4. **Open the record.** Add a first entry to `record.md` under *Phase log*:
   project created, date, and any framing the human has already given.

5. **Hand to conception.** Route to `agon-conceive` to work through theme,
   question, thesis, genre, venue, and voice. Do not pre-fill those fields with
   your own guesses — elicit them.

## Note

If the user is clearly mid-thought about *what* they want to write, capture it,
create the project, and flow straight into conception rather than making them
repeat themselves. The scaffolding should be near-invisible; the conversation is
the point.
