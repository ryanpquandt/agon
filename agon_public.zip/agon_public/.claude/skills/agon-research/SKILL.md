---
name: agon-research
description: Phase 2 of Agon. Map the relevant literature for a project and split it into must-read-before-drafting vs. citable-but-not-essential. Dispatches the research-scout subagent, then works with the human to finalize an honest, short must-read list. Use after conception, before reading.
---

# Phase 2 — Map research

Goal: a `reading-plan.md` with two honest lists — a *short* must-read-before-
drafting set, and a larger citable-but-not-essential set. The split is the
deliverable.

Governing rules: `CLAUDE.md`. Read the project's `brief.md` and `record.md` first.

## Procedure

1. **Get the human's map first.** Before searching, ask what they already know
   the piece must engage — the key works, the obvious opponents, the people who
   will be annoyed if uncited. This is their field; their prior is the anchor.
   Capture it.

2. **Dispatch the scout.** Launch the `research-scout` subagent with the brief
   and the human's starting map. The scout mines `reference/articles/` and the
   writer's own `reference/notes/` (when present) *before* the web, and
   returns a categorized, annotated bibliography plus relevant prior notes of
   the writer's as **suggestions** — flagging anything it could not verify.
   (It never invents sources; sanity-check before anything enters the plan.)

3. **Reconcile, agonistically.** Bring the scout's findings together with the
   human's map. This is the friction point of the phase:
   - **Defend a short must-read list.** The instinct is to read everything; resist
     it. A work belongs in must-read only if it could *change the argument* —
     refute the thesis, pre-empt the contribution, or supply the strongest
     opposing view. Push back on anything the human wants to promote that's merely
     relevant. Push back equally if they're *omitting* a work that genuinely
     threatens the thesis because it's inconvenient.
   - Everything else is citable-but-not-essential. Real, but not blocking.

4. **Verify honestly.** Don't let an unverified citation into the plan. If the
   scout flagged something `[unverified]`, either confirm it or mark it for the
   human to check. Never fabricate.

5. **Write the plan.** Populate `reading-plan.md`. For each must-read item, the
   note must say *why it could change the argument* — not just that it's related.

## The gate

Before closing, ensure the must-read list has survived a real winnowing: at least
one work the human initially wanted to include was reasoned down to "citable" (or
one they wanted to skip was reasoned up to "must-read"), and the call is logged in
`record.md`. A must-read list that nobody pushed on is usually too long.

## Close

- Finalize `reading-plan.md`.
- Set `Status: reading`.
- Log the must-read/citable decisions and any rejected inclusions in `record.md`.
- Hand to `agon-reading` — and prepare to *stop*. The next phase is the human's
  to do, not yours to race past.
